package com.company.AnnaNicholsU1Capstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnnaNicholsU1CapstoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnnaNicholsU1CapstoneApplication.class, args);
	}

}
